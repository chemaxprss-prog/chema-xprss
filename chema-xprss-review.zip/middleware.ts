import { createServerClient } from "@supabase/ssr";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";


export async function middleware(request: NextRequest) {

  let response = NextResponse.next({
    request,
  });


  const supabase = createServerClient(

    process.env.NEXT_PUBLIC_SUPABASE_URL!,

    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,

    {

      cookies: {

        getAll() {

          return request.cookies.getAll();

        },


        setAll(cookiesToSet) {

          cookiesToSet.forEach(
            ({ name, value, options }) => {

              request.cookies.set(
                name,
                value
              );

              response.cookies.set(
                name,
                value,
                options
              );

            }
          );

        },

      },

    }

  );


  const {
    data:{
      session
    }
  } = await supabase.auth.getSession();



  const pathname = request.nextUrl.pathname;



  if(
    pathname.startsWith("/admin") &&
    !session
  ){

    return NextResponse.redirect(
      new URL("/login", request.url)
    );

  }



  return response;

}



export const config = {

 matcher:[
   "/admin/:path*"
 ]

};