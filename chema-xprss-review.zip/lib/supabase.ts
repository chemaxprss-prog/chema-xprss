import { createBrowserClient } from "@supabase/ssr";


const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!.trim();

const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!.trim();


export const supabase = createBrowserClient(
  supabaseUrl,
  supabaseKey
);